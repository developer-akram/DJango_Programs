from django.db import models

class Notification(models.Model):
    email = models.CharField(max_length=100,null=True,blank=True,default='No email')
    mobile = models.CharField(max_length=10,null=True,blank=True,default="Empty")
    scenario = models.CharField(max_length=100)
    message = models.CharField(max_length=100)
    info = models.CharField(max_length=100)
# Create your models here.
