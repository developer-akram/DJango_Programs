from django.shortcuts import render, redirect
from  main.models import *
def index(request):
    if request.method== "POST":
        email = request.POST['email']
        mobile = request.POST['mobile']
        scenario = request.POST['scenario']
        message = request.POST['message']
        info = request.POST['info']
        data = Notification(email = email, mobile = mobile, scenario = scenario, message = message, info = info)
        data.save()
        return redirect('/main')
    return render(request, 'main/index.html',{'data':Notification.objects.all()})

def update(request):
    data = Notification.objects.get(pk = request.GET['q'])
    if request.method == "POST":
        data.email = request.POST['email']
        data.mobile = request.POST['mobile']
        data.scenario = request.POST['scenario']
        data.message = request.POST['message']
        data.info = request.POST['info']
        data.save()
        return redirect('/main')
    return render(request, 'main/update.html',{'data':data})

def delete(request):
    data = Notification.objects.get(pk = request.GET['q'])
    data.delete()
    return redirect('/main')

# Create your views here.
