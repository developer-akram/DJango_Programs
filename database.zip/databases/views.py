from django.shortcuts import render

def index(request):
    return render(request, 'database/index.html')

def dataadd(request):
    return render(request, 'database/dataadd.html')

def update(request):
    return render(request, 'database/update.html')

def viewdata(request):
    return render(request, 'database/viewdata.html')

def registration(request):
    return render(request, 'database/registration.html')

    
# Create your views here.
